ALTER TABLE llx_c_gestionparc_boxes_def ADD UNIQUE INDEX uk_boxes_def (file, entity, note);
